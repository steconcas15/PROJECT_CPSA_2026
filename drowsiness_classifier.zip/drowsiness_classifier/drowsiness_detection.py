"""
=============================================================================
 Drowsiness Detection via Complementary Filter
 Sensor: STM BlueCoin / CPSA (LSM6DSM)
 Author: ---
=============================================================================

 DETECTED EVENTS:
   1. SUDDEN DROP   — fast forward head fall  (|dθ/dt| high, duration short)
   2. NOD           — head nod down and back   (oscillation within ~300–800 ms)
   3. SLOW DRIFT    — gradual forward drift    (sustained pitch deviation > threshold)

 INPUT FILE FORMAT (BlueCoin CSV, 4-line header):
   Logged started on,DD/MM/YYYY HH:MM:SS
   Feature,Gyroscope  (or Accelerometer)
   Nodes,<node_name>
   <blank line>
   Date,HostTimestamp,NodeName,NodeTimestamp,RawData,X (dps),Y (dps),Z (dps)
   ...

 GYROSCOPE  units : dps  (degrees per second)
 ACCELEROMETER units : mg (milli-g)

=============================================================================
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import Patch
import warnings
warnings.filterwarnings("ignore")


# =============================================================================
#  ██████╗  █████╗ ██████╗  █████╗ ███╗   ███╗███████╗████████╗███████╗██████╗ ███████╗
#  ██╔══██╗██╔══██╗██╔══██╗██╔══██╗████╗ ████║██╔════╝╚══██╔══╝██╔════╝██╔══██╗██╔════╝
#  ██████╔╝███████║██████╔╝███████║██╔████╔██║█████╗     ██║   █████╗  ██████╔╝███████╗
#  ██╔═══╝ ██╔══██║██╔══██╗██╔══██║██║╚██╔╝██║██╔══╝     ██║   ██╔══╝  ██╔══██╗╚════██║
#  ██║     ██║  ██║██║  ██║██║  ██║██║ ╚═╝ ██║███████╗   ██║   ███████╗██║  ██║███████║
#  ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚══════╝
# =============================================================================
#
#  Modifica questi parametri per effettuare il tuning del sistema.
#  Ogni parametro ha un commento che spiega cosa controlla e in quale
#  direzione modificarlo.
#
# =============================================================================

REFRACTORY_SEC = 2.0

# --- FILE DI INPUT -----------------------------------------------------------
# Sostituisci questi percorsi con i tuoi file di guida da analizzare
GYRO_CSV  = "20260617_114001_Gyroscope.csv"
ACCEL_CSV = "20260617_114001_Accelerometer.csv"

# --- MONTAGGIO DEL SENSORE ---------------------------------------------------
# Definisce quale asse fisico del sensore corrisponde al pitch (testa su/giù).
# Dipende da come è posizionato il BlueCoin sulla testa del guidatore.
#   'X', 'Y', oppure 'Z'
# Convenzione: asse positivo = testa che scende in avanti
PITCH_GYRO_AXIS  = 'X'   # Asse giroscopio per la velocità angolare di pitch
PITCH_ACCEL_AXIS = 'X'   # Asse accelerometro per la componente di pitch
VERT_ACCEL_AXIS  = 'Z'   # Asse accelerometro per la componente verticale (gravità)

# Se il sensore è montato "al contrario" rispetto alla convenzione:
#   True  → inverte il segno dell'asse
#   False → lascia il segno invariato
INVERT_GYRO_PITCH  = False
INVERT_ACCEL_PITCH = False

# --- FILTRO COMPLEMENTARE ----------------------------------------------------
# Alpha: peso del giroscopio nell'integrazione (0 < alpha < 1)
#   Valori alti (0.97–0.99) → il filtro si fida più del gyro
#     PRO: risponde bene a movimenti rapidi
#     CONTRO: la deriva del gyro si accumula più lentamente ma non viene corretta
#   Valori bassi (0.90–0.95) → correzione accelerometrica più forte
#     PRO: meno deriva a lungo termine
#     CONTRO: più sensibile alle vibrazioni/accelerazioni del veicolo
# Punto di partenza consigliato: 0.96
CF_ALPHA = 0.96

# Gating dell'accelerometro: se |a_total - g| > questo valore [in g],
# il termine accelerometrico viene disabilitato (veicolo in accelerazione/frenata).
# Aumenta se hai molti falsi blocchi in guida normale.
# Diminuisce se vuoi più protezione da vibrazioni.
ACCEL_GATE_THRESHOLD_G = 0.15   # [g]

# --- BASELINE E CALIBRAZIONE -------------------------------------------------
# Finestra temporale iniziale usata per stimare la postura "neutra" del guidatore [secondi].
# Deve contenere solo postura normale, senza sonnolenza.
# Aumenta se il guidatore impiega più tempo a stabilizzarsi all'avvio.
CALIBRATION_WINDOW_SEC = 10.0

# Finestra della media mobile per aggiornare la baseline durante la guida [secondi].
# Baseline troppo veloce (valore basso): si adatta alla sonnolenza, perdi eventi
# Baseline troppo lenta (valore alto): non compensa cambio postura intenzionale
BASELINE_UPDATE_SEC = 30.0

# --- PARAMETRI EVENTO 1: CADUTA BRUSCA ---------------------------------------
# Soglia di velocità angolare di pitch [dps] oltre la quale si considera "veloce"
# Aumenta se hai troppi falsi positivi su buche stradali
# Diminuisce se le cadute brusche non vengono rilevate
SUDDEN_DROP_GYRO_THRESH_DPS = 10.0 # 40.0

# Angolo minimo di deviazione dalla baseline perché si registri l'evento [gradi]
SUDDEN_DROP_ANGLE_THRESH_DEG = 10.0 # 8.0

# Finestra temporale entro cui deve avvenire la caduta [secondi]
# (caduta brusca = angolo raggiunto in meno di questo tempo)
SUDDEN_DROP_WINDOW_SEC = 0.40 # 0.25

# --- PARAMETRI EVENTO 2: AMMICCO (NOD) ---------------------------------------
# Escursione angolare minima per qualificare un nod [gradi]
NOD_ANGLE_MIN_DEG = 8.0 # 8.0 

# Durata massima e minima del nod completo (giù + ritorno) [secondi]
# Un ammicco reale dura tipicamente 0.3–0.8 s
NOD_DURATION_MIN_SEC = 0.20
NOD_DURATION_MAX_SEC = 0.90 # 0.90

# Soglia di velocità angolare minima per rilevare l'inizio del nod [dps]
NOD_ONSET_GYRO_THRESH_DPS = 2.0 # 15.0

# --- PARAMETRI EVENTO 3: DERIVA LENTA ----------------------------------------
# Angolo di deviazione dalla baseline oltre il quale si segnala deriva [gradi]
SLOW_DRIFT_ANGLE_THRESH_DEG = 10.0

# Tempo minimo di permanenza sopra la soglia prima di generare allerta [secondi]
# Aumenta per evitare falsi positivi su curve stradali lunghe
# Diminuisce per rilevare prima la sonnolenza
SLOW_DRIFT_DURATION_SEC = 2.5

# Velocità angolare massima durante la deriva perché si consideri "lenta" [dps]
# (distingue la deriva da sonnolenza da un movimento intenzionale veloce)
SLOW_DRIFT_MAX_GYRO_DPS = 12.0

# --- RESAMPLING E INTERPOLAZIONE ---------------------------------------------
# Frequenza di campionamento target per l'elaborazione [Hz]
# Deve essere ≤ della ODR (Output Data Rate) reale del sensore più lento.
# Nel nostro caso, l'ODR del sensore sembra di 20Hz. Consideriamo quindi f_s = 20Hz.
# Aumentare migliora la risoluzione temporale ma aumenta il carico computazionale.
TARGET_ODR_HZ = 100.0   # for example, 100Hz -> 10 ms timestep

# --- VISUALIZZAZIONE ---------------------------------------------------------
# True  → mostra i grafici a schermo dopo l'elaborazione
# False → salva solo il file PNG senza mostrare
SHOW_PLOTS = True

# Percorso di output per il grafico PNG
PLOT_OUTPUT_PATH = "drowsiness_result.png"


# =============================================================================
#  FINE PARAMETRI — da qui in poi non è necessario modificare nulla
# =============================================================================


# ---------------------------------------------------------------------------
# 1. CARICAMENTO FILE CSV BlueCoin
# ---------------------------------------------------------------------------

def load_bluecoin_csv(path: str) -> pd.DataFrame:
    """
    Carica un file CSV BlueCoin/CPSA saltando le 4 righe di header.
    Converte la colonna Date in datetime e calcola un timestamp float in secondi
    a partire dall'inizio del file.
    """
    df = pd.read_csv(path, skiprows=4)
    df.columns = [c.strip() for c in df.columns]
    df['datetime'] = pd.to_datetime(df['Date'], format='%d/%m/%Y %H:%M:%S.%f')
    t0 = df['datetime'].iloc[0]
    df['t_sec'] = (df['datetime'] - t0).dt.total_seconds()
    return df.reset_index(drop=True)


def extract_axis(df: pd.DataFrame, axis: str, unit_col_hint: str) -> pd.Series:
    """
    Estrae la colonna dati per l'asse specificato ('X', 'Y', 'Z').
    Cerca colonne che iniziano con X/Y/Z seguiti da spazio o parentesi.
    """
    for col in df.columns:
        if col.upper().startswith(axis.upper() + ' ') or col.upper().startswith(axis.upper() + '('):
            return df[col].astype(float)
    # fallback: cerca esattamente il nome asse
    if axis.upper() in df.columns:
        return df[axis.upper()].astype(float)
    raise KeyError(f"Asse '{axis}' non trovato nelle colonne: {df.columns.tolist()}")


# ---------------------------------------------------------------------------
# 2. RESAMPLING E SINCRONIZZAZIONE
# ---------------------------------------------------------------------------
# L'interpolazione viene fatta perchè i dati letti dai CSV non sono a intervalli di tempo 
# regolari, ma il filtro complementare e il rilevamento eventi funzionano meglio su una
# griglia temporale uniforme. La funzione resample_to_uniform_grid prende i timestamp originali (t) 
# e i valori del segnale (y) e li interpola su una nuova griglia temporale uniforme con frequenza fs. 
# Restituisce i nuovi timestamp uniformi e i corrispondenti valori del segnale interpolati.

def resample_to_uniform_grid(t: np.ndarray, y: np.ndarray,
                              fs: float) -> tuple[np.ndarray, np.ndarray]:
    """
    Interpola un segnale a timestep irregolari su una griglia uniforme
    a frequenza fs [Hz].
    """
    t_end = t[-1]
    t_uniform = np.arange(0.0, t_end, 1.0 / fs)
    y_uniform = np.interp(t_uniform, t, y)
    return t_uniform, y_uniform


# ---------------------------------------------------------------------------
# 3. FILTRO COMPLEMENTARE
# ---------------------------------------------------------------------------

def complementary_filter(t: np.ndarray,
                          gyro_dps: np.ndarray,
                          accel_mg_pitch: np.ndarray,
                          accel_mg_vert: np.ndarray,
                          alpha: float,
                          gate_thresh_g: float) -> np.ndarray:
    """
    Filtro complementare discreto per la stima del pitch.

    Equazione:
        θ[k] = α · (θ[k-1] + ω[k] · dt)  +  (1-α) · θ_accel[k]

    Il termine accelerometrico viene disabilitato (gating) quando il modulo
    dell'accelerazione totale si discosta di più di gate_thresh_g dalla gravità,
    indicando accelerazioni del veicolo che distorcerebbero la stima.

    Args:
        t            : array tempi uniformi [s]
        gyro_dps     : velocità angolare di pitch [dps]
        accel_mg_pitch: componente accelerometro sull'asse pitch [mg]
        accel_mg_vert : componente accelerometro verticale [mg]
        alpha        : coefficiente del filtro (peso gyro)
        gate_thresh_g: soglia gating accelerometro [g]

    Returns:
        theta : angolo di pitch stimato [gradi]
    """
    n = len(t)
    theta = np.zeros(n)

    # Stima pitch da accelerometro: atan2(a_pitch, a_vert) [gradi]
    # accel in mg → convertiamo in g dividendo per 1000
    ap_g = accel_mg_pitch / 1000.0
    av_g = accel_mg_vert  / 1000.0
    theta_accel = np.degrees(np.arctan2(ap_g, np.abs(av_g)))

    # Inizializzazione con la prima lettura accelerometrica
    theta[0] = theta_accel[0]

    for k in range(1, n):
        dt = t[k] - t[k - 1]

        # Passo di integrazione giroscopio
        theta_gyro_pred = theta[k - 1] + gyro_dps[k] * dt

        # Gating: controlla se siamo in condizione quasi-statica
        a_total_g = np.sqrt(ap_g[k]**2 + av_g[k]**2)
        is_static = abs(a_total_g - 1.0) < gate_thresh_g

        if is_static:
            theta[k] = alpha * theta_gyro_pred + (1.0 - alpha) * theta_accel[k]
        else:
            # Veicolo in accelerazione: usa solo il giroscopio
            theta[k] = theta_gyro_pred

    return theta


# ---------------------------------------------------------------------------
# 4. STIMA BASELINE
# ---------------------------------------------------------------------------

def compute_baseline(theta: np.ndarray, t: np.ndarray,
                     cal_window_sec: float,
                     update_window_sec: float,
                     fs: float) -> np.ndarray:
    """
    Stima la postura neutra del guidatore.

    - Fase di calibrazione: media sui primi cal_window_sec secondi.
    - Aggiornamento continuo: media mobile su update_window_sec secondi
      (applicata solo quando theta è vicino alla baseline, per non
      incorporare eventi di sonnolenza nella stima).
    """
    n = len(theta)
    baseline = np.zeros(n)

    cal_samples = int(cal_window_sec * fs)
    cal_samples = min(cal_samples, n)
    initial_base = np.mean(theta[:cal_samples])
    baseline[:cal_samples] = initial_base

    update_win = int(update_window_sec * fs)

    for k in range(cal_samples, n):
        start = max(0, k - update_win)
        # Media solo dei campioni vicini alla baseline corrente
        window = theta[start:k]
        close_mask = np.abs(window - baseline[k - 1]) < 5.0  # entro 5°
        if close_mask.sum() > update_win // 4:
            baseline[k] = np.mean(window[close_mask])
        else:
            baseline[k] = baseline[k - 1]

    return baseline


# ---------------------------------------------------------------------------
# 5. RILEVAMENTO EVENTI
# ---------------------------------------------------------------------------

class DrowsinessEvent:
    """Contenitore per un singolo evento di sonnolenza rilevato."""
    def __init__(self, event_type: str, t_start: float, t_peak: float,
                 delta_angle: float, max_gyro: float):
        self.event_type  = event_type    # 'SUDDEN_DROP', 'NOD', 'SLOW_DRIFT'
        self.t_start     = t_start       # [s] inizio evento
        self.t_peak      = t_peak        # [s] picco massimo deviazione
        self.delta_angle = delta_angle   # [°] deviazione dalla baseline
        self.max_gyro    = max_gyro      # [dps] picco velocità angolare

    def __repr__(self):
        return (f"[{self.event_type:12s}] t={self.t_start:.2f}s "
                f"Δθ={self.delta_angle:.1f}° ω_max={self.max_gyro:.1f}dps")


def detect_events(t: np.ndarray,
                  theta: np.ndarray,
                  baseline: np.ndarray,
                  gyro_dps: np.ndarray,
                  fs: float,
                  params: dict) -> list[DrowsinessEvent]:
    """
    Rilevamento dei tre pattern di sonnolenza sul segnale di pitch filtrato.

    Usa una macchina a stati semplice per evitare doppi trigger sullo
    stesso evento.
    """
    events = []
    n = len(t)

    # Numero di campioni corrispondenti alle finestre temporali
    sudden_win  = int(params['sudden_drop_window_sec'] * fs)
    drift_min   = int(params['slow_drift_duration_sec'] * fs)
    nod_min_win = int(params['nod_duration_min_sec'] * fs)
    nod_max_win = int(params['nod_duration_max_sec'] * fs)

    # Deviazione dalla baseline
    delta = theta - baseline

    # Stato della macchina a stati
    in_sudden    = False
    in_nod       = False
    in_drift     = False
    nod_start    = 0
    drift_start  = 0
    last_event_t = -999.0  # periodo refrattario: evita doppi trigger ravvicinati. inizializzato a -999 per
    

    # analisi del segnale punto per punto 
    for k in range(sudden_win, n):
        # estrazione variabili correnti
        d    = delta[k]
        omega = abs(gyro_dps[k])
        t_now = t[k]

        if t_now - last_event_t < REFRACTORY_SEC:
            continue

        # ── EVENTO 1: CADUTA BRUSCA ──────────────────────────────────────────
        # Alta velocità angolare + deviazione significativa in breve finestra
        window_delta = delta[k - sudden_win:k]
        window_gyro  = np.abs(gyro_dps[k - sudden_win:k])
        if (d > params['sudden_drop_angle_thresh_deg']
                and omega > params['sudden_drop_gyro_thresh_dps']
                and window_gyro.max() > params['sudden_drop_gyro_thresh_dps']
                and (window_delta.max() - window_delta.min()) > params['sudden_drop_angle_thresh_deg']):
            events.append(DrowsinessEvent(
                'SUDDEN_DROP', t_now - params['sudden_drop_window_sec'], t_now,
                d, omega))
            last_event_t = t_now

        # ── EVENTO 2: AMMICCO (NOD) ──────────────────────────────────────────
        # Velocità angolare supera soglia di onset → avvia finestra nod
        if not in_nod and omega > params['nod_onset_gyro_thresh_dps']:
            in_nod = True
            nod_start = k

        if in_nod:
            elapsed_samples = k - nod_start
            # Se la testa è tornata vicino alla baseline → fine nod
            if abs(d) < params['nod_angle_min_deg'] / 2:
                if nod_min_win <= elapsed_samples <= nod_max_win:
                    # Nod valido: misura la deviazione massima durante la finestra
                    nod_delta = delta[nod_start:k]
                    peak_delta = nod_delta.max() if nod_delta.max() > abs(nod_delta.min()) else nod_delta.min()
                    nod_gyro   = np.abs(gyro_dps[nod_start:k]).max()
                    if abs(peak_delta) > params['nod_angle_min_deg']:
                        events.append(DrowsinessEvent(
                            'NOD', t[nod_start], t_now,
                            abs(peak_delta), nod_gyro))
                        last_event_t = t_now
                in_nod = False
                nod_start = 0
            # Timeout: finestra troppo lunga → non è un nod
            elif elapsed_samples > nod_max_win:
                in_nod = False
                nod_start = 0

        # ── EVENTO 3: DERIVA LENTA ────────────────────────────────────────────
        # Deviazione sostenuta + bassa velocità angolare (movimento lento)
        if (d > params['slow_drift_angle_thresh_deg']
                and omega < params['slow_drift_max_gyro_dps']):
            if not in_drift:
                in_drift = True
                drift_start = k
            elif (k - drift_start) >= drift_min:
                # Deriva sufficientemente lunga → allerta
                drift_delta = delta[drift_start:k].max()
                drift_gyro  = np.abs(gyro_dps[drift_start:k]).max()
                events.append(DrowsinessEvent(
                    'SLOW_DRIFT', t[drift_start], t_now,
                    drift_delta, drift_gyro))
                last_event_t = t_now
                in_drift = False
                drift_start = 0
        else:
            in_drift = False
            drift_start = 0

    return events


# ---------------------------------------------------------------------------
# 6. VISUALIZZAZIONE
# ---------------------------------------------------------------------------

COLORS = {
    'SUDDEN_DROP' : '#E74C3C',   # rosso
    'NOD'         : '#F39C12',   # arancio
    'SLOW_DRIFT'  : '#8E44AD',   # viola
}

LABELS = {
    'SUDDEN_DROP' : 'Caduta brusca',
    'NOD'         : 'Ammicco (nod)',
    'SLOW_DRIFT'  : 'Deriva lenta',
}


def plot_results(t: np.ndarray,
                 theta: np.ndarray,
                 baseline: np.ndarray,
                 gyro_dps: np.ndarray,
                 delta: np.ndarray,
                 events: list[DrowsinessEvent],
                 output_path: str,
                 show: bool = True):
    """
    Produce un grafico a 3 pannelli:
      1. Pitch stimato + baseline + eventi
      2. Velocità angolare di pitch
      3. Deviazione dalla baseline (Δθ)
    """
    fig = plt.figure(figsize=(16, 9))
    fig.suptitle('Rilevamento Sonnolenza — Filtro Complementare', fontsize=14, fontweight='bold')
    gs = gridspec.GridSpec(3, 1, hspace=0.45)

    ax1 = fig.add_subplot(gs[0])
    ax2 = fig.add_subplot(gs[1], sharex=ax1)
    ax3 = fig.add_subplot(gs[2], sharex=ax1)

    # --- Pannello 1: Pitch ---------------------------------------------------
    ax1.plot(t, theta,    color='#2980B9', lw=1.2, label='Pitch θ [°]', zorder=2)
    ax1.plot(t, baseline, color='#27AE60', lw=1.5, ls='--', label='Baseline', zorder=2)
    ax1.set_ylabel('Pitch [°]')
    ax1.set_title('Angolo di pitch stimato (filtro complementare)')
    ax1.grid(True, alpha=0.3)

    # Evidenzia eventi su tutti i pannelli
    for ev in events:
        color = COLORS[ev.event_type]
        for ax in [ax1, ax2, ax3]:
            ax.axvspan(ev.t_start, ev.t_peak, alpha=0.18, color=color, zorder=1)
            ax.axvline(ev.t_peak, color=color, lw=1.2, alpha=0.7, zorder=3)

    # Legenda eventi
    legend_patches = [Patch(color=COLORS[k], label=LABELS[k]) for k in COLORS]
    legend_patches.append(
        plt.Line2D([0], [0], color='#2980B9', lw=1.2, label='Pitch θ'))
    legend_patches.append(
        plt.Line2D([0], [0], color='#27AE60', lw=1.5, ls='--', label='Baseline'))
    ax1.legend(handles=legend_patches, loc='upper right', fontsize=8, ncol=3)

    # --- Pannello 2: Velocità angolare gyro ----------------------------------
    ax2.plot(t, gyro_dps, color='#16A085', lw=0.9, label='ω pitch [dps]')
    ax2.axhline(0, color='gray', lw=0.6, ls='--')
    ax2.set_ylabel('ω [dps]')
    ax2.set_title('Velocità angolare di pitch (giroscopio)')
    ax2.grid(True, alpha=0.3)
    ax2.legend(loc='upper right', fontsize=8)

    # --- Pannello 3: Deviazione dalla baseline --------------------------------
    ax3.fill_between(t, delta, 0,
                     where=(delta >= 0), alpha=0.4, color='#E74C3C', label='Δθ > 0 (testa avanti)')
    ax3.fill_between(t, delta, 0,
                     where=(delta < 0),  alpha=0.4, color='#3498DB', label='Δθ < 0 (testa indietro)')
    ax3.plot(t, delta, color='#2C3E50', lw=0.8, alpha=0.7)
    ax3.axhline(0, color='gray', lw=0.8)

    # Soglie eventi
    ax3.axhline( SUDDEN_DROP_ANGLE_THRESH_DEG, color='#E74C3C', lw=0.7, ls=':', alpha=0.7)
    ax3.axhline( SLOW_DRIFT_ANGLE_THRESH_DEG,  color='#8E44AD', lw=0.7, ls=':', alpha=0.7)
    ax3.set_ylabel('Δθ [°]')
    ax3.set_xlabel('Tempo [s]')
    ax3.set_title('Deviazione dalla baseline (Δθ = θ − baseline)')
    ax3.grid(True, alpha=0.3)
    ax3.legend(loc='upper right', fontsize=8)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f"\n[✓] Grafico salvato: {output_path}")

    if show:
        plt.show()
    else:
        plt.close()


# ---------------------------------------------------------------------------
# 7. REPORT TESTUALE
# ---------------------------------------------------------------------------

def print_report(events: list[DrowsinessEvent], duration_sec: float):
    """Stampa un report testuale degli eventi rilevati."""
    print("\n" + "=" * 60)
    print("  REPORT RILEVAMENTO SONNOLENZA")
    print("=" * 60)
    print(f"  Durata sessione  : {duration_sec:.1f} s  ({duration_sec/60:.1f} min)")
    print(f"  Totale eventi    : {len(events)}")
    counts = {k: 0 for k in COLORS}
    for ev in events:
        counts[ev.event_type] += 1
    print(f"    Cadute brusche : {counts['SUDDEN_DROP']}")
    print(f"    Ammicchi (nod) : {counts['NOD']}")
    print(f"    Derive lente   : {counts['SLOW_DRIFT']}")
    print("-" * 60)
    if events:
        print("  DETTAGLIO EVENTI:")
        for i, ev in enumerate(events, 1):
            print(f"  {i:3d}. {ev}")
    else:
        print("  Nessun evento di sonnolenza rilevato.")
    print("=" * 60)


# ---------------------------------------------------------------------------
# 8. PIPELINE PRINCIPALE
# ---------------------------------------------------------------------------

def main():
    print("[1/6] Caricamento file CSV...")
    gyro_df  = load_bluecoin_csv(GYRO_CSV)
    accel_df = load_bluecoin_csv(ACCEL_CSV)

    print(f"      Giroscopio  : {len(gyro_df)} campioni, durata {gyro_df['t_sec'].iloc[-1]:.1f}s")
    print(f"      Accel.      : {len(accel_df)} campioni, durata {accel_df['t_sec'].iloc[-1]:.1f}s")

    print("[2/6] Estrazione assi e resampling...")
    # Asse giroscopio pitch
    gyro_raw = extract_axis(gyro_df, PITCH_GYRO_AXIS, 'dps')
    if INVERT_GYRO_PITCH:
        gyro_raw = -gyro_raw

    t_g, gyro_uniform = resample_to_uniform_grid(
        gyro_df['t_sec'].values, gyro_raw.values, TARGET_ODR_HZ)

    # Assi accelerometro
    ap_raw = extract_axis(accel_df, PITCH_ACCEL_AXIS, 'mg')
    av_raw = extract_axis(accel_df, VERT_ACCEL_AXIS,  'mg')
    if INVERT_ACCEL_PITCH:
        ap_raw = -ap_raw

    # Estende l'accelerometro sulla stessa griglia del giroscopio
    t_end = min(t_g[-1], accel_df['t_sec'].iloc[-1])
    t_common = t_g[t_g <= t_end]
    gyro_common = gyro_uniform[:len(t_common)]

    ap_common = np.interp(t_common, accel_df['t_sec'].values, ap_raw.values)
    av_common = np.interp(t_common, accel_df['t_sec'].values, av_raw.values)

    print(f"      Griglia comune: {len(t_common)} campioni a {TARGET_ODR_HZ} Hz")

    print("[3/6] Applicazione filtro complementare...")
    theta = complementary_filter(
        t_common, gyro_common, ap_common, av_common,
        CF_ALPHA, ACCEL_GATE_THRESHOLD_G)

    print("[4/6] Stima baseline guidatore...")
    baseline = compute_baseline(
        theta, t_common,
        CALIBRATION_WINDOW_SEC, BASELINE_UPDATE_SEC, TARGET_ODR_HZ)

    print("[5/6] Rilevamento eventi di sonnolenza...")
    params = {
        'sudden_drop_gyro_thresh_dps'  : SUDDEN_DROP_GYRO_THRESH_DPS,
        'sudden_drop_angle_thresh_deg' : SUDDEN_DROP_ANGLE_THRESH_DEG,
        'sudden_drop_window_sec'       : SUDDEN_DROP_WINDOW_SEC,
        'nod_angle_min_deg'            : NOD_ANGLE_MIN_DEG,
        'nod_duration_min_sec'         : NOD_DURATION_MIN_SEC,
        'nod_duration_max_sec'         : NOD_DURATION_MAX_SEC,
        'nod_onset_gyro_thresh_dps'    : NOD_ONSET_GYRO_THRESH_DPS,
        'slow_drift_angle_thresh_deg'  : SLOW_DRIFT_ANGLE_THRESH_DEG,
        'slow_drift_duration_sec'      : SLOW_DRIFT_DURATION_SEC,
        'slow_drift_max_gyro_dps'      : SLOW_DRIFT_MAX_GYRO_DPS,
    }
    delta  = theta - baseline
    events = detect_events(t_common, theta, baseline, gyro_common,
                           TARGET_ODR_HZ, params)

    print_report(events, t_common[-1])

    print("[6/6] Visualizzazione risultati...")
    plot_results(t_common, theta, baseline, gyro_common, delta,
                 events, PLOT_OUTPUT_PATH, SHOW_PLOTS)


if __name__ == "__main__":
    main()
